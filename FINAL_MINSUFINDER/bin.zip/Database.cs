﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.IO;
using System.Windows.Forms;

namespace StudentCrudApp
{
    public class DatabaseHelper
    {
        // Connection string using AttachDBFilename for Service-Based Database (.mdf)         // Adjust relative path or use |DataDirectory| depending on your project setup 
        private readonly string connString =
            @"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=" +
            Application.StartupPath + "\SchoolDB.mdf;Integrated Security=True;";


        public bool InsertStudent(Student student)
        {
            using (SqlConnection conn = new SqlConnection(connString))
            {
                string query = "INSERT INTO Students (FirstName, LastName, Course, Age) VALUES (@Fn, @Ln, @Course, @Age)";
                using (SqlCommand cmd = new SqlCommand(query, conn))
                {
                    cmd.Parameters.AddWithValue("@Fn", student.FirstName); cmd.Parameters.AddWithValue("@Ln", student.LastName); cmd.Parameters.AddWithValue("@Course", student.Course); cmd.Parameters.AddWithValue("@Age", student.Age); conn.Open();
                    return cmd.ExecuteNonQuery() > 0;
                }
            }
        }

        public DataTable GetAllStudents()
        {
            using (SqlConnection conn = new SqlConnection(connString))
            {
                string query = "SELECT Id, FirstName, LastName, Course, Age FROM Students ORDER BY Id DESC";
                using (SqlDataAdapter adapter = new SqlDataAdapter(query, conn))
                {
                    DataTable dt = new DataTable(); adapter.Fill(dt); return dt;
                }
            }
        }

        public bool UpdateStudent(Student student)
        {
            using (SqlConnection conn = new SqlConnection(connString))
            {
                string query = "UPDATE Students SET FirstName = @Fn, LastName = @Ln, Course = @Course, Age = @Age WHERE Id = @Id";
                using (SqlCommand cmd = new SqlCommand(query, conn))
                {
                    cmd.Parameters.AddWithValue("@Id", student.Id); cmd.Parameters.AddWithValue("@Fn", student.FirstName); cmd.Parameters.AddWithValue("@Ln", student.LastName); cmd.Parameters.AddWithValue("@Course", student.Course); cmd.Parameters.AddWithValue("@Age", student.Age); conn.Open();
                    return cmd.ExecuteNonQuery() > 0;
                }
            }
        }

        public bool DeleteStudent(int id)
        {
            using (SqlConnection conn = new SqlConnection(connString))
            {
                string query = "DELETE FROM Students WHERE Id = @Id"; using (SqlCommand cmd = new SqlCommand(query, conn))
                {
                    cmd.Parameters.AddWithValue("@Id", id); conn.Open();
                    return cmd.ExecuteNonQuery() > 0;
                }
            }
        }
    }
}
